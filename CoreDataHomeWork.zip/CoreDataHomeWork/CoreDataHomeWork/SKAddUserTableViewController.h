//
//  SKAddUserTableViewController.h
//  CoreDataHomeWork
//
//  Created by Кирилл on 21.02.17.
//  Copyright © 2017 Кирилл. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SKUserTableViewController.h"

@class SKUser;

@interface SKAddUserTableViewController : UITableViewController

@property (strong, nonatomic) NSString *userName;
@property (strong, nonatomic) NSString *userLastName;
@property (strong, nonatomic) NSString *userMail;
@property (strong, nonatomic) SKUser *user;
@property (weak, nonatomic) SKUserTableViewController *usersViewController;

- (IBAction)doneButtonAction:(UIBarButtonItem *)sender;
- (IBAction)cancelButtonAction:(UIBarButtonItem *)sender;

@end
