
//
//  SKAddUserTableViewController.m
//  CoreDataHomeWork
//
//  Created by Кирилл on 21.02.17.
//  Copyright © 2017 Кирилл. All rights reserved.
//

#import "SKAddUserTableViewController.h"
#import "SKUserTableViewCell.h"
#import "SKUser.h"

@interface SKAddUserTableViewController () <UITableViewDelegate>

@end

typedef enum {
    
    nameRowInTable,
    lastNameRowInTable,
    mailRowInTable,
    
} SKStudentRowsInTable;

@implementation SKAddUserTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UI

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.row == nameRowInTable) {
        
        SKUserTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"addUserName"];

        self.userName = cell.nameTextField.text;
        
        return cell;
        
    } else if (indexPath.row == lastNameRowInTable) {
        
        SKUserTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"addUserLastName"];

        self.userLastName = cell.lastNameTextField.text;

        return cell;
        
    } else {
        
        SKUserTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"addUserMail"];

        self.userMail = cell.mailTextField.text;

        return cell;
    }
    
}

#pragma mark - Actions

- (IBAction)doneButtonAction:(UIBarButtonItem *)sender {
    
    SKUser *user = [[SKUser alloc] init];
    
    user.name = self.userName;
    user.lastName = self.userLastName;
    user.mail = self.userMail;
    
    [self.usersViewController.users addObject:user];
        
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (IBAction)cancelButtonAction:(UIBarButtonItem *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end
