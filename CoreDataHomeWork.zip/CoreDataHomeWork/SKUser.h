//
//  SKUser.h
//  CoreDataHomeWork
//
//  Created by Кирилл on 21.02.17.
//  Copyright © 2017 Кирилл. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SKUser : NSObject

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *lastName;
@property (strong, nonatomic) NSString *mail;

@end
