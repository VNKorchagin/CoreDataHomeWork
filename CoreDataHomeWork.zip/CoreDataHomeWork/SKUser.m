//
//  SKUser.m
//  CoreDataHomeWork
//
//  Created by Кирилл on 21.02.17.
//  Copyright © 2017 Кирилл. All rights reserved.
//

#import "SKUser.h"

@implementation SKUser

@end
