//
//  SKUserTableViewCell.m
//  CoreDataHomeWork
//
//  Created by Кирилл on 21.02.17.
//  Copyright © 2017 Кирилл. All rights reserved.
//

#import "SKUserTableViewCell.h"

@implementation SKUserTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
